# icon-detection > 2024-09-22 11:58am
https://universe.roboflow.com/justmessingaround/icon-detection-tcjel

Provided by a Roboflow user
License: CC BY 4.0

